package com.example.demo.unittest;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;

import javax.annotation.Resource;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mock.env.MockEnvironment;
import org.springframework.stereotype.Component;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.example.demo.entity.EntityBean;


@Configuration
/*@PropertySource({"classpath:test.json"})*/
public class ResourceConfiguration {
	

	  @Resource
	  private Environment env;		
   
	 /*
      @Bean
	  public EntityBean resource() {
			EntityBean resource = new EntityBean();
			resource.setId(Integer.valueOf(env.getProperty("id")));
			System.out.print("Id of bean"+Integer.valueOf(env.getProperty("id")));
			resource.setCommittee_name(env.getProperty("committee_name"));
			resource.setCommittee_description(env.getProperty("committee_description"));
			resource.setActive(Boolean.valueOf(env.getProperty("active")));
			resource.setCreated_by(env.getProperty("created_by"));
			resource.setUpdated_by(env .getProperty("updated_by"));
			resource.setTime_created(env.getProperty("time_created"));
			resource.setTime_updated(env.getProperty("time_updated"));
			return resource;	
		  
	 }	*/

	@Bean  
	public EntityBean returnData() {
		EntityBean bean = new EntityBean();
		try {
	    	  JSONParser jsonParser = new JSONParser();
	    	  Object obj=jsonParser.parse(new FileReader("src/test/resources/test.json"));
	    	  JSONObject object = (JSONObject)obj;
	    	  long i=(long)object.get("id");
	    	  System.out.print("id value"+i);
	    	  bean.setId((int)(long)object.get("id"));
	    	  bean.setCommittee_name((String)object.get("committee_name"));
	    	  bean.setCommittee_description((String)object.get("committee_description"));
	    	  bean.setCreated_by((String)object.get("created_by"));
	    	  bean.setUpdated_by((String)object.get("updated_by"));
	    	  bean.setTime_created((String)object.get("time_created"));
	    	  bean.setTime_updated((String)object.get("time_updated"));
	          bean.setActive((Boolean)object.get("active"));
	      }catch(IOException | ParseException e) {
	    	  e.printStackTrace();
	      }
		return bean;

	}
           
    	  
      
      
}


