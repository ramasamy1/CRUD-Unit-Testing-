package com.example.demo.unittest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.apache.catalina.Context;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.context.support.StaticApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.DAO.CommiteDAO;
import com.example.demo.DAO.CommiteDAOImpl;
import com.example.demo.entity.EntityBean;
import com.example.demo.service.CommiteServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = ResourceConfiguration.class)
public class CommiteTest {
	
	
	private CommiteDAOImpl dao;

    @Autowired 
    private EntityBean context;

	private CommiteServiceImpl committeeservice;


	/*@Spy
	List<EntityBean> committees = new ArrayList<>();*/
	
/*	@Captor
	ArgumentCaptor<EntityBean> captor = ArgumentCaptor.forClass(EntityBean.class);*/
	

	//this will execute before @test test cases  
	@Before
	public void setup() {
	 dao=spy(new CommiteDAOImpl());//create a spy on real object   //here actual mocking class called 
     committeeservice= new CommiteServiceImpl(dao);
  
	/*	
	  committees=getCommitteeList();*/
	    
	 /*System.out.println("ID of peroperty file"+context.getId());*/
   
      //creating entity object
      /*e1=new EntityBean(4,"code-4","this is fourth record","samy","guru","30-09-2018","30-09-2018",false);*/
      /* e2=new EntityBean(1,"code-24","this is sixth record","rama","logu","30-09-2018","30-09-2018",true);*/
      

	   //stubbing for test cases
       doNothing().when(dao).addCommite(any(EntityBean.class));
	   when(dao.findById(1)).thenReturn(context);
	   when(dao.findAll()).thenReturn(Arrays.asList(context));
	   doNothing().when(dao).updateCommite(1,context);
	   doNothing().when(dao).deleteCommite(anyInt());
 
      // if id is 1 then it will return arraylist records 
  
      
	}
	
	
	
	
	// here mocked service findAll() will called,object will be return when findAll method will be called
	//toFindAll committee

	@Test
	public void testfindAll() {
	     assertEquals(committeeservice.findAll(),Arrays.asList(context));
	    /* verify(dao,times(1)).findAll();*/
	}

	//to find A committee
  
	@Test
	public void testfindById() {
		
		int id = 1;
		EntityBean bean= dao.findById(id);
		
		assertNotNull(context);
		assertEquals(1,bean.getId());
		System.out.print("get ID"+bean.getId());
		assertEquals("code-24",bean.getCommittee_name());
		assertEquals("samy1ui34",bean.getCreated_by());
		/*System.out.print("isActive or not"+bean.isActive());*/
		assertEquals(true,bean.isActive());
			
		
	}
	
    // to add A Committee
	@Test
	public void testAddCommittee() {
		doNothing().when(dao).addCommite(any(EntityBean.class));
		committeeservice.addCommite(context);
		
		//captor intialization not did that's throws error
	 /*   verify(dao,times(1)).addCommite(captor.capture());;*/
        
		/*assertEquals(captor.getValue().getCommittee_name(),"code-24");
		*/

		
		/*//NotaMockException will throw,because we not mocking list name /****committees****/ 
		/*verify(committees,times(2)).add(any(EntityBean.class));*/	
	}
	
	// to delete A Committee
	@Test
	public void testDeleteById() {
		  doNothing().when(dao).deleteCommite(anyInt());
		  dao.deleteCommite(anyInt()); 
		  verify(dao,times(1)).deleteCommite(anyInt());
	}
	
	
	@Test
	public void testUpdateByIdAndObject() {
		doNothing().when(dao).updateCommite(1,context);
	    //update  
		dao.updateCommite(1,context);   
	    context.setCommittee_name("code-24");
	 	/*System.out.print("print the object"+context.getCommittee_name());*/
	}
	
	
	
	// preparing committee list
/*	 public List<EntityBean> getCommitteeList(){
		EntityBean bean = new EntityBean();
		bean.setId(1);
		bean.setCommittee_name("code-24");
		bean.setCommittee_description("this is for making list");
		bean.setActive(true);
		bean.setCreated_by("loga");
		bean.setUpdated_by("nathan");
		bean.setTime_created("01-10-2018");
		bean.setTime_updated("01-10-2018");
		
		EntityBean bean1 = new EntityBean();
		bean1.setId(2);
		bean1.setCommittee_name("code-33");
		bean1.setCommittee_description("this is for making  2nd list");
		bean1.setActive(true);
		bean1.setCreated_by("rama");
		bean1.setUpdated_by("nd");
		bean1.setTime_created("01-10-2018");
		bean1.setTime_updated("01-10-2018");
	   committees.add(bean);
	   committees.add(bean1);
	   
	   return committees;
	
    }
	
	*/
	
	
	
	
	
/*	//no data found
    @Test
    public void testNullReturnIfNoDataFound() {
       List all = new LinkedList();	
       when(dao.findAll()).thenReturn(all);
       List result = cs.findAll();
       System.out.print("mocked out data result"+result);
       // to check mocked out DAO  method called or not 
       verify(dao).findAll();
       assertEquals(null,result);
    }
    
	@Test
    public void findAll() {
		List listOfAllCommitte= dao.findAll();
		assertNotNull(listOfAllCommitte);
		System.out.println("size of "+listOfAllCommitte.size());
		assertEquals(2,listOfAllCommitte.size());
	}
	
	
	
*/
}
