package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.CommiteDAO;
import com.example.demo.DAO.CommiteDAOImpl;
import com.example.demo.entity.EntityBean;
@Service
public class CommiteServiceImpl implements CommiteService {

    private CommiteDAO dao;
	
    public CommiteServiceImpl(CommiteDAO dao) {
		// TODO Auto-generated constructor stub
		this.dao=dao;
	}

	@Override
	public void addCommite(EntityBean bean) {
   		// TODO Auto-generated method stub
		    dao.addCommite(bean);
	}

	@Override
	public EntityBean findById(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

	@Override
	public List<EntityBean> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public void updateCommite(int id,EntityBean bean) {
		// TODO Auto-generated method stub
		dao.updateCommite(id,bean);
	}

	@Override
	public void deleteCommite(int id) {
		// TODO Auto-generated method stub
		dao.deleteCommite(id);
	}

	
	
	
	
}
