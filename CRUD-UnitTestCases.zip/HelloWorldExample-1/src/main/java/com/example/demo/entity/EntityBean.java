package com.example.demo.entity;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="reporting_committee")
public class EntityBean {
	
	@Id
	@Column(unique=true)
	private int id;
	private String committee_name;
    private String committee_description;
    private String created_by;
    private String updated_by;
    private String time_created;
	private String time_updated;
    private boolean active;
   
	public EntityBean() {
		
	}
   
    public int getId() {
		return id;
	}
    
	public void setId(int id) {
		this.id = id;
	}
	public String getCommittee_name() {
		return committee_name;
	}
	public void setCommittee_name(String committee_name) {
		this.committee_name = committee_name;
	}
	
	public String getCommittee_description() {
		return committee_description;
	}
	public void setCommittee_description(String committee_description) {
		this.committee_description = committee_description;
	}
	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}


	public String getTime_created() {
		return time_created;
	}


	public void setTime_created(String time_created) {
		this.time_created = time_created;
	}


	public String getTime_updated() {
		return time_updated;
	}


	public void setTime_updated(String time_updated) {
		this.time_updated = time_updated;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
	



}
