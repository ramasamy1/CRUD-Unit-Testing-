package com.example.demo.DAO;

import java.util.List;
import java.util.Optional;


import com.example.demo.entity.EntityBean;

public interface CommiteDAO {

	public void addCommite(EntityBean bean);
	
	public EntityBean findById(int id);
	
	public List<EntityBean> findAll();
	
	public void updateCommite(int id,EntityBean bean);
	
	public void deleteCommite(int id);
	
}
