package com.example.demo.DAO;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Repository;


import com.example.demo.entity.EntityBean;



@Repository
public class CommiteDAOImpl implements CommiteDAO {


	@Autowired
	private CustomCrudInterface cci;
	
	@Autowired
	private EntityBean context;
	
	@Override
	public void addCommite(EntityBean bean) {
      // TODO Auto-generated method stub	
/*		System.out.print("checking null or not "+cci.findById(bean.getId()));
		if(cci.findById(bean.getId()).isPresent()) {
			throw new DuplicateKeyException("CommiteDAOImpl:DuplicateKeyException:IF ID Already Exists:Exception throw");
		}else if(!cci.findById(bean.getId()).isPresent()){
			 cci.save(bean);
		}*/
		cci.save(context);	
	}

	@Override
	public EntityBean findById(int id) {
		// TODO Auto-generated method stub
		if(Integer.valueOf(id) != null) {
			/*cci.findById(id).get();*/
		}
	 return context;
	}

	@Override
	public List<EntityBean> findAll() {
		// TODO Auto-generated method stub
		/*List<EntityBean> commite = new ArrayList<>();
		if(commite.isEmpty() && commite != null) {
			cci.findAll().forEach(commite::add);
		}*/

		List<EntityBean> context_list=Arrays.asList(context);
		return context_list;
	}

	@Override
	public void updateCommite(int id,EntityBean bean) {
		// TODO Auto-generated method stub	   
		/*if(Integer.valueOf(id) != null && bean != null) {
			cci.save(bean);
		}*/
		cci.save(context);	
		
 	}

	@Override
	public void deleteCommite(int id) {
		// TODO Auto-generated method stub
		/*if(Integer.valueOf(id) != null) {
			cci.deleteById(id);
		}	*/
		cci.deleteById(context.getId());
	}
	
}
