package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.EntityBean;

import com.example.demo.service.CommiteServiceImpl;



@RestController
public class CommiteController {

	static Logger logger = Logger.getLogger(CommiteServiceImpl.class);
	
	@Autowired
	private CommiteServiceImpl csi;
	
	
	@RequestMapping(value="/Commites",method=RequestMethod.POST)
	public void addCommite(@RequestBody EntityBean bean) { 
	    csi.addCommite(bean);					
	}
	
	@RequestMapping(value="/Commites/{id}",method=RequestMethod.GET)
	public EntityBean findById(@PathVariable("id") int id) {
		return csi.findById(id);
	}
	
	@RequestMapping(value="/Commites",method=RequestMethod.GET)
	public List<EntityBean> findAll(){
		return csi.findAll();
	}
	
	@RequestMapping(value="/Commites/{id}",method=RequestMethod.PUT)
	public void updateCommite(@PathVariable("id") int id,@RequestBody EntityBean bean) {
		csi.updateCommite(id,bean);
	}
	
	@RequestMapping(value="/Commites/{id}",method=RequestMethod.DELETE)
	public void deleteCommite(@PathVariable("id") int id) {
		csi.deleteCommite(id);
	}
	
	
}
